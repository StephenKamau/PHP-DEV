-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 04, 2018 at 03:32 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rental`
--

-- --------------------------------------------------------

--
-- Table structure for table `apartments`
--

CREATE TABLE `apartments` (
  `id` int(11) NOT NULL,
  `apartmentname` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `rentpermonth` decimal(10,2) NOT NULL,
  `principalcontact` varchar(15) NOT NULL,
  `imageurl` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `apartments`
--

INSERT INTO `apartments` (`id`, `apartmentname`, `location`, `description`, `status`, `rentpermonth`, `principalcontact`, `imageurl`) VALUES
(1, 'Las Vegas Downtown Apartments', 'Nairobi', 'Modern Living Space', 0, '65000.00', '071546949', 'http://10.2.22.57:86/dev/rentalfinder/images/5bffb37a68806.png'),
(2, 'Los Angeles Heights', 'Mombasa', 'Ocean view', 0, '65000.00', '07466464', 'http://10.2.22.57:86/dev/rentalfinder/images/5bffb414c6c68.png'),
(3, 'Ret', 'Juja', 'Apartments', 0, '85000.00', '07556666', 'http://197.136.195.141:86/dev/rentalfinder/images/5c04fcb26d32b.png');

-- --------------------------------------------------------

--
-- Table structure for table `responsibility`
--

CREATE TABLE `responsibility` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `description` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `emailaddress` varchar(50) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `password` text NOT NULL,
  `gender` varchar(15) NOT NULL,
  `dateofbirth` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `emailaddress`, `phone`, `password`, `gender`, `dateofbirth`) VALUES
(1, 'Stephen', 'Kamau', 'stephenarchimedes@gmail.com', '0716403799', '$2y$10$Ur24HRQaZTDLlzUDoqoBiegU8SBYnURICD/OVnYQRrMHN2GGy2rzq', 'male', '1998-08-12'),
(2, 'Stephen', 'Kamau', 'stephenarchimedesq@gmail.com', '076464664', '$2y$10$q52khXhagvR8Gmflk7iG4ubVtFjIY2KrgaC9.3HDTUbLfJIzDIR.i', 'male', '1998-12-02'),
(3, 'Stephen', 'Kamau', 'stephenarchimedesqw@gmail.com', '076464664', '$2y$10$Y2V1FzihEl2FJCD7rRSFQO7UUJkBMee7GawU6BmvaRbwflGR.l0ay', 'male', '1998-12-02'),
(4, 'Billy', 'ogada', 'billyogada@gmail.com', '0712345678', '$2y$10$wh7rq4zNj/mjN..2A2/xVe5qQknTgFaRZOk9.RrZV7rqjabsPQ1hm', 'male', '1990-12-25');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `apartments`
--
ALTER TABLE `apartments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `responsibility`
--
ALTER TABLE `responsibility`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `apartments`
--
ALTER TABLE `apartments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `responsibility`
--
ALTER TABLE `responsibility`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
